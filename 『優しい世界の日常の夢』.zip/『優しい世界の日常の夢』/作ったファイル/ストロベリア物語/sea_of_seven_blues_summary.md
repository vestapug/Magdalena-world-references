
# Sea of Seven Blues Summary

## Culture
The Sea of Seven Blues is a vast and diverse ocean world inhabited almost entirely by merfolk. They have no taboo against eating fish and live a seafaring lifestyle, sleeping aboard boats and relying on fishing. Their culture is deeply spiritual; the sea is worshiped, and it is believed that the souls of the dead return to the ocean to become blessings of marine life. Leadership is flexible, with leaders chosen situationally rather than fixed. Festivals often involve sharing large catches like marlin or ...

## Climate
This ocean realm spans many marine environments, from shallow sunlit lagoons to deep dark waters. Waters are rich in diverse sea life like cobalt clams, luminous sardines, and azure sharks. The climate varies locally but supports abundant marine ecosystems. Bioluminescent fish light up the night sea, and storms are marked by deep indigo waves. Shallow coastal areas with sunlit waters provide safe play zones for children.

## Society
Merfolk society revolves around fishing, communal sharing, and reverence for the ocean. Major catches are shared among the community, often becoming reasons for celebration. Decorative use of shells and marine colors is common, and cobalt shells even serve as currency. Social structure is cooperative and adaptive, with no permanent rulers. Spiritual customs such as funerals returning souls to the sea reinforce their connection to the marine world.

---

# 七青の海 要約

## 文化
七青の海は人魚族がほぼすべてを占める広大で多様な海洋世界です。魚食にタブーはなく、船上で寝泊まりし漁労に頼る生活を送っています。文化は海への深い信仰に根差しており、亡くなった魂が海に還り魚介の恵みとなると信じられています。固定的な支配者ではなく、状況に応じて指導者が選ばれる柔軟なリーダーシップが特徴です。マグロやカジキなどの大漁時には共同で祝う祭礼や、海と祖先を讃える語りの伝統があります。

## 気候
この海洋圏には浅瀬の陽光あふれるラグーンから光の届かない深海まで、多様な海環境が広がっています。コバルト貝や発光イワシ、瑠璃色の鮫など多様な海洋生物が生息しています。地域ごとに気候は異なりますが、豊かな海洋生態系が支えられています。発光魚が夜の海を照らし、嵐では深い藍の波が現れます。浅瀬の陽光きらめく水域は子どもたちの安全な遊び場にもなっています。

## 社会
人魚族の社会は漁労と共同分配、そして海への敬虔な信仰を中心に成り立っています。大きな漁獲は共同で分け合い祝宴の理由となります。貝殻や海の色を使った装飾が一般的で、コバルト貝の殻は通貨にもなります。恒常的な支配者はいない協力的かつ適応的な社会であり、魂を海に還す葬礼などの信仰習慣が海との結びつきを強めています。
