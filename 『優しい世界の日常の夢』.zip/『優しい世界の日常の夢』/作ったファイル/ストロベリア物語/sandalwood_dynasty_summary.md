
# Sandalwood Dynasty Summary

## Culture
The Sandalwood Dynasty is an ancient kingdom with a refined bureaucracy led by the king. It values agriculture and scholarship, producing famous silk, ceramics, and tea. Scholars and artists are highly respected; tradition and ethics are prioritized over individualism or practicality. Agricultural rituals are held both by the royal family and commoners, strengthening social cohesion. Extended patriarchal families are common, yet law protects equal rights for men and women, and women freely pursue educati...

## Climate
The dynasty has fertile lands with a temperate climate that supports abundant agriculture. Its fields, rivers, and forests enable production of rice, vegetables, tea, and silk. Seasonal agricultural rituals reflect the importance of nature’s cycles to society.

## Society
A hierarchical but stable society with an elaborate bureaucracy and deep respect for scholars and elders. Meals begin with elders’ greetings, reflecting etiquette and age order. The monarchy upholds harmony with other worlds and ethics rooted in history. Both vegetarian dishes favored by scholars and lavish feasts for nobles coexist, symbolizing moderation and abundance. Traditional colors like Ivory White for mourning and Jade Green for virtue embody its aesthetic and moral values.

---

# 栴檀王朝 要約

## 文化
栴檀王朝は悠久の歴史を誇る王朝で、国王を頂点とする精緻な官僚制度を持っています。農業と学問を重んじ、絹や陶磁器、茶の名産地として知られます。学者や芸術家が尊敬され、実用性より倫理、個性より伝統が重視されます。農耕儀礼は王族から庶民まで古来より広く行われ、社会の結束を高めています。父系大家族が多い一方、法律は男女平等を保障し、女性も学問や職業を自由に選択できます。料理は川魚や豆腐の庶民料理から、アヒルの瑪瑙焼きや真珠の肉団子といった豪奢な宮廷料理まで多様で、翡翠緑や螺鈿黒など象徴性の強い料理や伝統色が文化に深く結びついています。

## 気候
王朝は肥沃な土地と温暖な気候に恵まれ、農業が盛んです。田畑や川、森林が稲作、野菜、茶、絹など多様な産業を支えています。農耕儀礼は自然の循環を重視する社会観を反映しています。

## 社会
精緻な官僚制度と年功序列の礼儀を重んじる安定した階層社会です。食事は年長者の「いただきます」で始まり、年齢や礼儀が尊重されます。君主は歴史に根差した倫理観と他世界との調和を重視しています。学者に愛される菜食や高官が楽しむ贅沢な宮廷料理が共存し、節度と豊かさを象徴します。象牙白の喪服や翡翠緑などの伝統色が美意識と道徳観を体現しています。
