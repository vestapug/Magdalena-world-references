
# Rainbow Empire Summary

## Culture
The Rainbow Empire is renowned for its delicate yet magnificent culture, emphasizing diversity and beauty. It is a constitutional monarchy ruled by descendants of the first emperor, with politics run by a noble council. Its philosophy values freedom and diversity, expressed through the idea that “just as light reveals many colors, righteousness brings diversity.” Arts flourish, including jewelry, crafts, music, painting, and equestrian sports. Nobles enjoy lavish lifestyles using fine foods like foie gras...

## Climate
The empire spans vast lands including seas, with four distinct seasons and a slightly dry climate. Summers have strong sunshine, and the landscape supports wheat, cattle, grapes, and various crops. The climate nurtures rich agriculture and enables production of fine wines and cheeses.

## Society
Citizens value personal freedom and diverse lifestyles. Nobles dominate cultural life with artistic patronage, and musicianship on instruments like violin and piano is a marker of high status. International cultural exchange is encouraged, with the empire hosting global events. Social life integrates beauty with everyday experience: decorative crafts, colorful fashion, and gourmet cuisine permeate both noble and commoner life. Military and sports culture highlight honor and elegance rather than conquest.

---

# 彩虹の帝国 要約

## 文化
彩虹の帝国は、繊細かつ絢爛な文化で知られ、多様性と美を重んじます。初代皇帝の子孫を皇帝とする立憲君主制で、政治は貴族の評議会が運営しています。「光が多彩な色を見せるように、正しさが多様性をもたらす」という理念が重視されます。宝飾・工芸・音楽・絵画・馬上競技などの芸術が盛んで、貴族はフォアグラやキャビアなど豪華な料理を楽しみますが、搾取による贅沢は忌避されます。演奏会や舞踏会、馬上スポーツが盛んで、軍事も暴力ではなく優雅な名誉として表現されます。

## 気候
帝国は海を含む広大な領域に広がり、四季があり、やや乾燥した気候です。夏は日差しが強く、小麦や牛、ブドウなど多様な作物を育む農業が発達し、上質なワインやチーズが生産されています。

## 社会
市民は個人の自由と多様な生活を尊重します。貴族は芸術を後援し、ヴァイオリンやピアノなどの演奏が高い地位の象徴とされます。国際的な文化交流が奨励され、世界的なイベントを主催します。日常生活にも装飾や色彩が浸透し、美と実用が融合しています。軍事やスポーツは征服ではなく、名誉と優雅さを示す文化として機能しています。
