# Dracul Rex Summary

## Culture
Dracul Rex is a state where half-dragons play a leading role in politics, emphasizing military aesthetics and the sharing of food. Once seen as a spectacle state that exploited orphanages and ceremonial guards, it has undergone generational change. Younger half-dragons, who experienced hunger, now promote rituals where everyone shares meals. Military aesthetics are redefined as symbols of order, dignity, and health. Key cultural icons include the grand pork stew *Hojō no Buta*, the symbolic long-lasting *Currency Bread*, and *Ryūka-shu*, a sacred agave-based liquor divided into the communal *Ryūhi-shu* and the authoritative *Ryūō-shu*.

**日本語訳:**  
ドラクル・レクスは、半竜たちが政治を主導し、軍事美学と食の共有を重視する国家です。かつては孤児院や儀仗兵を利用する「見世物国家」と見なされていましたが、世代交代を経て健全化しました。飢えを経験した若い半竜たちは、儀礼で皆が食を分かち合う文化を推進し、軍事美学を「秩序」「威厳」「健全さ」の象徴として再定義しました。文化的象徴には、大鍋料理「豊穣の豚」、保存性の高い「貨幣パン」、神聖なリュウゼツラン酒「竜華酒」（庶民向けの「竜妃酒」と上層向けの「竜王酒」に区分）が含まれます。

---

## Climate
Dracul Rex lies in a cool climate with short summers and long, harsh winters. Historically plagued by food shortages, this changed with the rise of young half-dragons possessing mild weather-control abilities. They expanded greenhouse facilities, enabling the cultivation of diverse plants. As a result, food scarcity was resolved and dietary variety increased.

**日本語訳:**  
ドラクル・レクスは涼しい気候にあり、短い夏と長く厳しい冬が特徴です。かつては食糧不足に苦しみましたが、若い半竜の中に微弱な天候操作能力を持つ者が現れ、温室設備を拡張しました。これにより多様な植物が栽培されるようになり、食糧難は解消され、食文化も多様化しました。

---

## Society
Today, Dracul Rex presents itself as a “military aesthetic cultural state.” Young guards in white uniforms march under black banners, projecting strong contrasts of order and dignity. Once symbols of exploitation, ceremonial guards have become admired figures, with children aspiring to join them. Medals in golden hues, weapons of bluish-gray winter steel, and crimson flags recall both authority and the memory of past sacrifices. Internationally, Dracul Rex now strives to secure its place in the Magdalena world order by emphasizing culture, ritual, and shared food rather than force.

**日本語訳:**  
現在のドラクル・レクスは「軍事美学文化国家」としての姿を示しています。白い制服の儀仗兵たちが黒い軍旗の下で行進し、秩序と威厳を鮮烈に映し出します。かつては搾取の象徴だった儀仗兵も今では尊敬され、子供たちの憧れの職業となっています。黄金色の勲章、青みがかった灰色の厳冬鋼の武具、深紅の旗章は、権威と過去の犠牲の記憶をともに伝えます。国際的にも、ドラクル・レクスは力ではなく文化・儀礼・食の共有を通じてマグダレーナ世界の秩序に居場所を築こうと努力しています。

