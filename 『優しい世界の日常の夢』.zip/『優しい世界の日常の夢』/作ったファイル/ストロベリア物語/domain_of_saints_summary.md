
# Domain of Saints Summary

## Culture
The Domain of Saints is a city-state led by women known as Saints, who wield holy magic focused on healing wounds and curing illnesses. Prayer is central but expressed as simple heartfelt wishes rather than organized religion. Saints are revered as moral and spiritual leaders and raised from childhood in communal training. Men who inherit the power serve as guardian warriors protecting Saints and engaging in humanitarian work. Fasting and self-imposed hardships help Saints empathize with othe...

## Climate
The domain is surrounded by forests and has four seasons, with a slightly cool climate. Local vegetation like jade moss is valued for its healing properties and colors many symbolic items. The serene natural environment complements the domain’s role as a sanctuary for rest and healing, attracting pilgrims from other worlds seeking peace and care.

## Society
Saints serve as spiritual and ethical symbols; guardians protect them and assist with humanitarian aid. The community is matrilineal, with Saints and guardians living communally. The domain maintains political neutrality while actively offering international aid. Pilgrims arrive for healing, supported by rituals and gentle hospitality. Colors like Saint White, Prayer Pink, and Goddess Rainbow carry meanings of compassion, blessing, and reverence for diversity.

---

# 聖女領 要約

## 文化
聖女領は、傷や病を癒す神聖魔法を操る聖女たちが率いる都市国家です。祈りは重要視されますが、宗教的儀式というより素朴な願いとして表現されます。聖女たちは精神的・倫理的な象徴として崇められ、幼少期から共同体で教育を受けます。聖なる力を受け継いだ男性は守護戦士として聖女を護り、人道活動に従事します。聖女たちは他者の痛みを理解するため断食や苦行を行い、断食後は菓子や果物を囲んで「日常への帰還」を祝います。聖女色のシュー菓子や祈りのケーキ、蜂蜜入りパニス・ヴィタエなどの象徴的なお菓子が知られ、慈愛と癒しの文化を示しています。

## 気候
聖女領は森林地帯に囲まれ、四季がありながらやや冷涼な気候です。地元の翡翠苔などは薬効があり、象徴色としても重視されます。静かな自然環境は精神と身体の癒しの場としての役割を補完し、異世界から平和と治療を求める巡礼者を惹きつけています。

## 社会
聖女たちは精神的・道徳的な象徴として人々を導き、守護戦士が彼女たちを護り人道活動を支えます。母系社会であり、聖女と守護戦士は共同生活を営みます。国際的な人道支援を行いつつ中立を掲げ、巡礼者を癒すための儀式や優しい歓待が整っています。聖女白や祈祷紅、女神虹色といった伝統色には、慈愛・祝福・多様性への敬意が込められています。
