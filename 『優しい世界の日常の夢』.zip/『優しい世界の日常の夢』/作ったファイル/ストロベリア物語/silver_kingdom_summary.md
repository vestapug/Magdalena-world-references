
# Silver Kingdom Summary

## Culture
The Kingdom of Silver values dignity, faith, and artistic expression. Citizens are devout and worship natural deities such as dragons, with temples adorned with precious metals and crystals. The Temple Knights, chosen for virtue and learning, lead spiritually and politically. Poets enjoy high status under the law that “no poet may be punished for their poetry.” Epic and tragic poetry are popular. Alcohol culture thrives in rituals, with mead and wine widely consumed. Dairy and beekeeping are developed, pro...

## Climate
The kingdom enjoys four mild seasons: warm springs, cool autumns, and generally comfortable weather throughout the year. Its rich nature supports agriculture, livestock, beekeeping, and diverse flora. This abundant environment sustains the kingdom’s famed natural beauty and resources.

## Society
People are kind and reverent; religion permeates daily life. Temple Knights play central roles in defense, religion, and politics. Culture blends faith, poetry, and crafts, emphasizing dignity and moral virtue. Goods like silver, crystal, honey, dairy, and hunting products support trade, especially with the Steel Empire. Colors like Swan White and Crystal reflect purity and nobility, while Honey Gold and Cotton Snow White symbolize everyday blessings and labor.

---

# 白銀の王国 要約

## 文化
白銀の王国は威厳と信仰、芸術表現を重んじる文化を持っています。人々は敬虔で竜をはじめとする自然神を崇拝し、貴金属や水晶で飾られた神殿が各地にあります。人徳と学識で選ばれる神殿騎士は宗教・国防・政治において精神的指導者として強い影響力を持ちます。「詩を理由にその作者を罰してはならない」という法により詩人は高い地位を享受し、英雄叙事詩や悲劇が人気です。宗教儀礼でミードやワインが用いられ、酒文化が発達。酪農と養蜂が盛んで、多様なチーズや蜂蜜、ミードが生産されています。鹿・猪・熊などの狩猟やその保存食も名物。鉱業では金銀や宝石が採掘され、水晶が国家の象徴となっています。

## 気候
王国は四季があり、春は温暖、秋は涼しく、通年で過ごしやすい気候です。豊かな自然が農業、牧畜、養蜂、多様な植物を支えます。この豊かな環境が王国の美しい自然と資源を育んでいます。

## 社会
人々は善良で敬虔であり、宗教は日常生活に深く根ざしています。神殿騎士が防衛・宗教・政治で中心的役割を果たします。文化は信仰、詩、工芸が融合し、威厳と道徳を重んじます。銀や水晶、蜂蜜、乳製品、狩猟品などが交易を支え、特に鋼鉄の帝国と盛んに交易しています。白鳥色や水晶色は純粋や高貴を、蜂蜜酒色や綿雪白は日常の祝福や労働を象徴します。
