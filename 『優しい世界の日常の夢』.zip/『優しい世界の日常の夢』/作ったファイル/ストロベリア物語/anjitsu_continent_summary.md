
# Anjitsu Continent Summary

## Culture
Anjitsu Continent has no large states; instead, scattered villages each maintain unique customs and faiths. Every settlement worships local guardian or ritual gods whose names and natures vary. Ritual arts such as myth reenactments and animal-imitating dances are sacred and serious; performers sometimes enter trance states. Food culture distinguishes daily meals and festival feasts: fermented fruit-spice paste (Hanpe), millet dumplings, and local sake are daily staples, while rice dishes and s...

## Climate
The continent alternates between rainy and dry seasons, shaping diverse ecosystems. Some regions experience torrential rains inspiring awe and fear, while others face intense dry-season heat. Agriculture varies with terrain; some villages suffer food shortages in the dry season or floods in the rainy season, prompting seasonal migration and trade.

## Society
Communities value harmony while respecting individual emotions. Pilgrims, traveling priests, and storytellers connect villages and bring cultural exchange. Traveling workers spread crops like pumpkins abroad. Seasonal rituals and colors (e.g., Pomegranate Red, Benevolent Rain Green) express gratitude to deities and nature. Food and ritual taboos are flexible, especially for travelers, reflecting a tolerant worldview. Symbols like millet-gold in harvest festivals or red-blue wedding colors refle...

---

# 晏日大陸 要約

## 文化
晏日大陸には都市や国家はなく、山間や谷間に点在する集落がそれぞれ独自の習俗や信仰を守っています。各集落には守護神や祭祀神がいて、その名や性質は地域ごとに異なります。神話の再演や動物模倣の歌舞などの芸能は神聖で真剣に行われ、演者がトランス状態に入ることもあります。日常食とハレの日の食が明確に区別され、日常では発酵果実ペースト（ハヌペ）、雑穀団子、どぶろくなどが、祭礼では米飯やフウミなど小動物の薫製焼きが供されます。石榴やココナッツなどは神々と結びついた供物であり、蓮葉蛙のように雨季には食べてはいけないとされる動物もいます。

## 気候
雨季と乾季が交互に訪れ、多様な自然環境が広がります。豪雨が畏怖を呼ぶ地域もあれば、乾季の酷暑が厳しい地域もあります。地形や気候により農作物の安定性は異なり、乾季に食料不足や雨季の水害に見舞われる集落では、出稼ぎや季節的な交易が行われます。

## 社会
共同体の調和を重んじつつ、個人の感情や意思も尊重されます。巡礼者、遊行巫女、語り部などが各地を行き来し、文化交流を担います。出稼ぎ労働者はカボチャなどの作物を他地域に広めました。季節ごとの儀礼や伝統色（石榴紅、慈雨緑など）は神々や自然への感謝を表します。食や儀礼に関するタブーは寛容で、特に旅人には適用されないことも多く、寛大な世界観がうかがえます。粟穂金の収穫祭や赤青の新生彩の婚礼衣装など、集落ごとに多様でありながら共通の象徴表現が見られます。
