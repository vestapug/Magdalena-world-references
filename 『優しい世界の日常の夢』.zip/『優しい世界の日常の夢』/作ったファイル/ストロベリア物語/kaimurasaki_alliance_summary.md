
# Alliance of Tyrian Purple Summary

## Culture
The Alliance of Tyrian Purple is a network of desert coastal city-states inhabited primarily by a race of magicians who draw power from their own negative emotions. While magicians are central to society, non-magicians also live there. Their culture values resource management, strong bonds of kinship and mentorship, and coexistence. They acknowledge the dangers of negativity but believe in the significance of accepting darkness. The region is famous for luxury dyes like Tyrian purple and cochineal, as wel...

## Climate
The Alliance is located in an arid desert coastal region with a harsh, dry climate. The desert interior produces incense, while the coast supports marine life used for dyes. Magical animals like blazing lions and rock camels also inhabit the region, adapting to the desert’s extremes by channeling negative emotions into magic. The limited vegetation includes rare evergreens in uplands, while camels and other fauna reflect adaptation to the harsh terrain.

## Society
Magicians dominate social and cultural life, with strong familial and apprentice-teacher bonds shaping social networks. Authority is based more on trust and relationships than strict hierarchy. Magicians view themselves as “exotic” to outsiders and proudly use that uniqueness as cultural capital. Shared meals and emotional harmony play roles in social stability. The Alliance maintains a rich tradition of art, hospitality, and magical adaptation, and its products like dyes and spices are valuable exports...

---

# 貝紫の同盟 要約

## 文化
貝紫の同盟は、砂漠沿岸部に位置する都市国家群で、自己のネガティブな感情を魔力の源とする魔術師種族が中心となって暮らしています。魔術師が社会の核を担う一方、非魔術師も共に生活しています。資源管理や血縁・師弟関係などの強い絆、共存の理念が文化の柱です。ネガティブな感情の危険性を認識しつつも「闇を受け入れる意義」を重んじます。貝紫やコチニールといった高級染料や没薬・乳香などの香料が特産で、食文化では師や年長者への敬意を示す柔軟な食卓文化があり、クミンを効かせたラム串、ベジタリアンカレー、薔薇ペイストリーなど香り豊かな料理が楽しまれます。客人をもてなすコーヒー・紅茶文化も特徴です。

## 気候
貝紫の同盟は乾燥した砂漠沿岸地域にあり、厳しい乾燥気候に特徴づけられます。内陸部では没薬などの香料が産出され、沿岸部では貝紫など動物由来の染料が生産されます。灼熱ライオンや岩山ラクダといった魔術動物も生息し、ネガティブ感情を魔力として過酷な環境に適応しています。希少な常緑樹などわずかな植生や、ラクダなどの動物がこの厳しい環境に対応しています。

## 社会
社会・文化の中心は魔術師であり、血縁や師弟関係といった強い社会的絆により構築されています。権威は厳格な序列ではなく信頼と関係性に基づきます。自らの姿が外部から「異国風」に見えることを誇りとし、観光資源としても活用しています。共に食べることで魔術と感情の調和を図り、社会の安定を支えています。芸術や歓待、魔術的適応に富む文化を持ち、染料や香料などの産品は重要な輸出品です。
