
# Dragon-Scale Civilization Summary

## Culture
The Dragon-Scale Civilization thrives in jungles and highlands, led spiritually by a sacred king believed to have dragon-god blood. Men lead militarily while women lead religiously; inheritance is bilateral, creating a delicate political balance. Festivals with games, feasts, and animal sacrifices honor gods, and warriors are respected for courage and discipline. Music developed around rituals; the chief music priestess “Blessing Song Maiden” is traditionally a sister or daughter of the sacred king. Villages have their own festival music honoring guardian deities. Unique crops and animals are cultivated for ritual offerings, also fueling the economy. Alcohol culture is weak; people mainly drink cacao beverages and fruit juices. Meat plays a central role in cuisine, with ritual game meats and daily poultry or iguana. Architecture is grand and durable, decorated with religious art. Recently, exchanges with other worlds began, including trade and study abroad.

## Climate
The region combines dense jungle and high mountains, isolated from other civilizations. It has its own agricultural and calendrical systems. The climate supports crops like tomatoes, corn, cacao, and various ritual plants. Harsh terrain contributed to limited technology until recent foreign contact.

## Society
The sacred king and family are revered for divine blood and strength; they serve as religious and protective figures. Wild animals are worshipped as nature’s guardians. Strong local patriotism sometimes causes issues when emigrants return home, leaving children abroad. Social structure balances male military and female religious leadership. Rituals, arts, and colors like Cinnabar Red and Dragon-Rainbow symbolize faith and nature’s power. The people value courage, modesty, and connection to the divine.

---

# 竜鱗の文明 要約

## 文化
竜鱗の文明は密林と高地に栄える文明で、龍神の血を引くとされる聖王が精神的指導者です。男性は軍事、女性は宗教を率い、双系制のため政治権力は微妙な均衡にあります。遊戯や宴会を伴う祭りや動物供儀の儀式が盛んで、勇気と節度を重んじる戦士階級が尊敬されています。音楽は宗教儀式に伴って発展し、音楽神官長「祝福歌姫」は聖王の姉妹や娘が務めます。村や都市ごとに守護神を称える祭礼音楽があり、儀式用の動植物栽培が経済にも寄与しています。酒文化は弱く、カカオ飲料や果実ジュースが主流です。肉料理が発達しており、儀式での狩猟肉や日常の鶏肉・イグアナ肉が食されます。建築は荘厳で耐久性があり、宗教美術で飾られています。近年は貿易や留学など異世界との交流も始まりました。

## 気候
密林と高山が広がり、他文明から隔絶された土地です。独自の農耕・暦制が発達。気候はトマト、トウモロコシ、カカオなどの作物や儀式植物を支えています。厳しい地形により長らく科学技術は停滞していましたが、異世界との接触で変化が始まっています。

## 社会
聖王とその一族は神聖な血と力を持つ存在として崇敬され、宗教的・守護的役割を果たします。野生動物が自然の守護神として信仰されます。郷土愛が強く、移住者が子を残して帰郷する問題もあります。男性軍事・女性宗教の二元的リーダーシップが社会の基盤です。儀式や芸術、シナバル・レッドや龍彩などの色が信仰と自然の力を象徴します。人々は勇気、節度、神との結びつきを重んじます。
