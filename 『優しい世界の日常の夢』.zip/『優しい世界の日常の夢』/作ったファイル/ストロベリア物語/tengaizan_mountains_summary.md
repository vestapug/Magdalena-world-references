
# Tengaizan Mountains Summary

## Culture
The Tengaizan Mountains are a militaristic aristocratic state located near the Steel Empire. People value honesty, honor, and openly expressing anger as cultural virtues. Ancestor worship is the primary faith; honored ancestors are seen as clan guardians. Nature is also revered, as disasters are believed to be caused by its anger. Livelihood centers on pastoralism with sheep and yaks; livestock are never abandoned even during disasters. Cuisine distinguishes between “food of struggle” (meat and fish) an...

## Climate
The region is mountainous with a harsh natural environment and frequent disasters. Volcanic zones yield practical minerals like rock salt, iron, copper, and sulfur. The severe winters require preserved foods like dried yogurt, smoked fish, and jerky. The rugged terrain and climate shape both the people’s resilience and their disaster-response culture.

## Society
Governance is by military aristocrats whose political influence depends on their emergency response capabilities. Councils emphasize practical use of local resources during crises. Aristocrats enjoy imported goods in peacetime, but honor is earned through disaster relief and defense. Society integrates ancestor and nature worship, with ceremonies where nobles share sacrificial lamb with their ancestors. Social symbols like lamb-black cloaks denote family honor and protection. Honesty and readiness are ke...

---

# 天蓋山脈 要約

## 文化
天蓋山脈は鋼鉄の帝国近くに位置する軍事貴族政権国家で、人々は正直、名誉、怒りを素直に表すことを美徳としています。主要な信仰は祖霊崇拝で、名誉ある死者は氏族の守護霊とされます。また自然崇拝も盛んで、災害は自然の怒りが招くものと信じられています。生活基盤は羊やヤクなどの牧畜で、災害時でも家畜を見捨てません。食文化では「闘争の糧」（家畜肉や川魚）と「平和の糧」（ヨーグルトやチーズなど乳製品）を区別します。儀礼では輸入発酵茶が用いられ、庶民は野草茶を日常的に飲みます。人生の節目には「誓いの茶」を立会人とともに飲む文化があります。勝色や祖霊紅などの伝統色は名誉や祖先との結びつきを象徴します。

## 気候
この地域は山岳地帯で自然環境が厳しく、災害も多発します。火山帯からは岩塩、鉄、銅、硫黄など生活に必要な鉱物が採れます。厳冬に備えて乾乳酪、燻し魚、干し肉などの保存食が作られます。険しい地形と気候が人々の強靭さと災害対応文化を形作っています。

## 社会
統治は軍事貴族によって行われ、合議での発言力は緊急対応能力によって左右されます。危機時には地元産品を最大限活用し、平時には舶来品も楽しまれますが、名誉は防衛と救助で得られます。祖霊や自然崇拝が社会に根づき、貴族は祖霊に仔羊を捧げその肉を共に食す儀礼を行います。仔羊黒の外套のような象徴は家名と信義の継承を意味し、正直と備えが社会の中核価値となっています。
