
# Steel Empire Summary

## Culture
The Steel Empire originated from ancient nomadic tribes and evolved into a nation that values practicality and strength. Its culture blends the legacy of nomadic traditions with reforms that embraced diversity and prosperity. Distinctive features include vibrant underground arts such as songs and dances born from former orphan communities, bold black-themed urban fashion, and tourism based on nomadic life experiences. Culinary traditions emphasize preserved meats and dairy, complemented by imported wheat, fruits, and spices, creating diverse regional cuisines. Symbolic colors like austere black and dark green represent military prestige, while others such as obsidian black, celadon jade, and ember red embody resilience, spirituality, and openness to external influences.

## Climate
The Steel Empire spans cold and harsh environments, shaped by its nomadic heritage. Traditional foods and drinks like boiled lamb, hard yogurt cheese, smoked salmon, and rich milk tea reflect adaptations to severe winters. Preservation techniques—salting, drying, fermenting—are essential for survival. Northern glacial zones and steppes define its landscape, fostering a culture that values endurance and warmth amidst cold winds.

## Society
Historically patriarchal and militarized, the Steel Empire once marginalized those outside paternal order as “orphans,” forcing many underground. Reforms supported by the Silver Kingdom introduced gender-role fluidity, welfare for orphans, and open exchanges with other worlds. Today, it prospers as both a cultural and military power. Its army remains elite through relentless training and tradition, cooperating with allies to stabilize weaker or unstable states. Former underground beliefs like the Black-Faced Jackal deity and the “Big Brother of All Orphans” are now respected cultural assets and tourist attractions, reflecting a society that honors its past while embracing reform.



# 鋼鉄の帝国 要約

## 文化
鋼鉄の帝国は古代の遊牧民を起源とし、実用と強さを重んじる国家へと発展しました。遊牧時代の伝統と、多様性と豊かさを受け入れた改革が融合した文化を持ちます。かつて孤児たちが築いた地下社会から生まれた歌や踊り、黒を基調とした力強い都市ファッション、遊牧生活体験ツアーなどが特色です。食文化は保存肉や乳製品を基盤としつつ、小麦や果実、香辛料の輸入により多彩な地域料理が発展しました。厳しい黒や暗黒グリーンが軍事的威信を象徴し、黒檀色・青磁碧・熾朱などが耐久や精神性、外界への開放性を示す色として尊ばれています。

## 気候
鋼鉄の帝国は、遊牧の伝統に根ざした寒冷で厳しい環境に広がっています。茹で羊肉、硬いヨーグルトチーズ、スモークサーモン、濃厚なミルクティーといった伝統食品は、厳冬への適応を反映しています。塩漬け・乾燥・発酵といった保存技術は生存に欠かせません。北方の氷河地帯や草原がその風土を形づくり、冷たい風の中で温かさと忍耐を重んじる文化が育まれています。

## 社会
歴史的に家父長制と軍事化が進んだ社会であり、父権秩序から外れた者は「孤児」として地下生活を余儀なくされていました。白銀の王国の支援を受けた改革派が性役割の流動化、孤児への福祉、異世界交流を推進し、現在は文化と軍事の両面で繁栄しています。軍隊は伝統と鍛錬により精強さを維持し、同盟国と協力して不安定な国家を保護しています。かつての地下信仰である黒面野干や「すべての孤児たちの兄貴」も、今では観光資源として尊重され、過去を抱きしめながら改革を進める社会を象徴しています。
