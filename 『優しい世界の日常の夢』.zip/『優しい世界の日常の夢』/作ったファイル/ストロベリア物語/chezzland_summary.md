
# Chezzland Summary

## Culture
Chezzland is a vast and nature-rich continent inhabited by diverse species including catfolk, fox spirits, otterfolk, and centaurs. Each group maintains its own traditions and faith while living in harmony with their environment. Food culture varies widely by species: catfolk roast birds with herbs, otters steam salmon wrapped in leaves, centaurs barbecue bison, while herbs and berries are common to all. Curiosity drives active scholarly exchange and trade, with some species welcoming human settlers. A unified leadership is not favored; cultural diplomacy emerged only recently with the creation of the Chezzland Mediation Council to oversee interworld exchange.

## Climate
Chezzland features varied landscapes including snowy forests, temperate plains with extreme seasonal changes, and dry regions. Winters can be harsh and snowy in forests, while the plains see hot summers and cold winters. Rivers provide abundant salmon runs, and the diversity of terrain supports different subsistence lifestyles: hunting, fishing, herding, and trade. Its rich ecosystems allow for vibrant flora such as berries and herbs that are staples of its cuisine.

## Society
Chezzland’s societies are organized by species and prioritize respect for each other’s cultures without a central government. Catfolk and fox spirits historically led individual exchanges with other worlds, but lacked unified diplomacy. Recent persuasion and support from allied realms like the Rainbow Empire and Sandalwood Dynasty enabled the formation of the Chezzland Mediation Council, which handles cultural exchange, resource management, and interspecies diplomacy. Knowledgeable catfolk and fox scholars play a central role. Festivals like shared solstice feasts symbolize peaceful coexistence.

---

# チェッツランド 要約

## 文化
チェッツランドは、猫種族・妖狐族・カワウソ種族・ケンタウロスなど多様な種族が暮らす自然豊かな広大な大陸です。各種族は独自の文化や信仰を持ち、自然と調和した暮らしを続けています。食文化は種族ごとに異なり、猫種族のハーブ焼き鳥、カワウソ種族の鮭の葉包み蒸し、ケンタウロス族の野牛バーベキューなどがありますが、共通してハーブやベリーといった自然の食材が広く利用されています。好奇心旺盛な猫や妖狐たちは学術や交易で異世界と交流し、個人単位で人間の入植者を受け入れることもありました。全体を統一するリーダー文化はなく、近年になってようやく異世界交流を監督する「チェッツランド調停会」が発足しました。

## 気候
チェッツランドは雪深い森林、寒暖差の激しい平原、乾燥地帯など多様な地形を持ちます。森林では冬が厳しく、平原は夏暑く冬寒い環境です。豊かな河川では鮭が遡上し、多様な地形が狩猟・漁撈・牧畜・交易など各種族の生業を支えています。ベリーや香草など多彩な植物が豊かに自生し、食文化や祭礼にも生かされています。

## 社会
チェッツランドの社会は種族単位で構成され、中央集権的な統治はなく、互いの文化を尊重することを重視しています。猫種族や妖狐族が主体となって異世界との個別交流を進めてきましたが、正式な外交関係は長らく存在しませんでした。近年、「彩虹の帝国」「栴檀王朝」の支援と説得により、異世界との文化交流や資源管理、種族間の調整を担う「チェッツランド調停会」が設立され、猫や妖狐の学識者が中心となっています。冬至の多文化鍋のような祭礼は平和共存の象徴です。
