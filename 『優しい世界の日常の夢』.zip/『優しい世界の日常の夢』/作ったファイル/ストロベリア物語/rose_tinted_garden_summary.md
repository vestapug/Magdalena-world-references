
# Rose-Tinted Garden Summary

## Culture
The Rose‑Tinted Garden is an elegant aristocratic city‑state renowned for its court culture, arts, and tourism. Once citizenship required noble birth or adoption, but now an institution symbolically adopts applicants as the “Butterfly Queen’s children,” so visitors and residents coexist without barriers. Its economy revolves around tourism and cultural events such as balls, exhibitions, theater, and festivals. Imports of food and culture are refined with local artistry; dishes like rose pastries, lobster gratin, and rice cakes with legend‑tinted roses showcase aesthetic hospitality. Ancient poorhouses survive as symbols under the ethos “to be good is to be beautiful.” The Butterfly Queen loves art and supports beauty regardless of origin; courtiers strive to win her favor, but she values genuine love of beauty.

## Climate
As a small urban state, it relies on imported food. Its mild climate and rich cultural assets make it attractive for long stays; many residents and guests travel to Magda Island or the Rainbow Empire to enjoy different climates and cultures. The city is maintained as a “stage of beauty” with graceful scenery and refined architecture.

## Society
Society is aristocrat‑centered but open; there is little social gap between nobles and visitors. Goods and food maintain high quality standards, resulting in high prices. The Butterfly Queen emphasizes beauty over utility, saying, “Beauty may sometimes be useful, but even if not, it is still worthy.” Colors like Dream‑Haze, Rose‑Tear, and Butterfly Purple carry symbolic meaning, expressing aesthetics of beauty, danger sublimated into art, and legendary love. The city blends tourism, art, and gentle hospitality into an inclusive social model.

---

# 薔薇色の園 要約

## 文化
薔薇色の園は宮廷文化と芸術、観光で名高い優美な貴族都市国家です。かつて市民権は貴族出生や養子縁組が条件でしたが、現在は「胡蝶の女王」の養子とみなす制度があり、滞在者と住民が隔てなく共存しています。経済は観光と文化行事（舞踏会、展覧会、演劇、祝祭など）を中心に発展。食材や文化を輸入し、薔薇のペイストリーやロブスターの紅殻焼き、伝説の薔薇を使った薔薇のライスケーキなど、美的歓待として昇華しています。「善は美なり」の精神で古い救貧院が象徴的に残され、胡蝶の女王は出自を問わず美を愛し、廷臣たちは彼女の歓心を求めますが、彼女は真心ある美への愛を重んじます。

## 気候
小規模な都市国家で食料は輸入に頼ります。温和な気候と豊かな文化資産が長期滞在を誘い、住民や客はマグダ島や彩虹の帝国など他地域へ行き来して気候や文化の違いを楽しみます。都市全体が優美な景観と洗練された建築による「美の舞台」として整えられています。

## 社会
貴族中心ながら開かれた社会で、貴族と訪問者の格差はほぼありません。商品や食材は高水準を保ち、物価は高めです。胡蝶の女王は「美しいものはそれ自体で価値がある」と語り、実用より美を尊びます。夢霞色、涙薔薇色、蝶紫などの伝統色は美、過ちを昇華した危うい美、伝説の恋といった美学を象徴。観光と芸術、ゆるやかな歓待を融合させた包括的な社会モデルです。
