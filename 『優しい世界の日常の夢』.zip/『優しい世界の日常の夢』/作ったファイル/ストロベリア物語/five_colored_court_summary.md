
# Five-Colored Court Summary

## Culture
The Five-Colored Court is a vassal state under the Sandalwood Dynasty, famous for its vibrant court culture, lively commoners, and internal political struggles. The king has ceremonial authority but little power, spending time in the opulent harem, which leads fashion and entertainment trends but suffers from moral corruption and infighting among consorts. Bureaucrats control politics yet are plagued by factionalism and scandals. The crown prince, despite his youth, strives to be an ethical model and stud...

## Climate
The country has a year-round warm, humid tropical or subtropical climate. Citrus and herbs are widely used in cuisine, which favors refreshing, aromatic dishes. Being coastal, seafood is abundant, and fish sauce is a staple condiment. The climate supports vibrant open-air markets and lively outdoor lifestyles.

## Society
Politics is dominated by bureaucrats, often marred by self-interest and scandals; the media treats politics as consumable spectacle. Despite political dysfunction, civil life is energetic and socially flexible. The court radiates cultural influence through its harem’s fashions and crafts, while commoners enjoy festivals, night markets, and street performances. Bright colors are favored in clothing, furniture, and ceramics; vivid reds and greens are particularly popular, reflecting the society’s openness and joy.

---

# 五彩朝廷 要約

## 文化
五彩朝廷は栴檀王朝に従属する衛星国で、華やかな宮廷文化、活気ある民間、政権内部の争いが特徴です。国王は権威はあるものの実権は乏しく、豪奢な後宮で遊興にふけり、後宮はファッションや娯楽を先導する一方、妃たちの道徳腐敗や足の引っ張り合いが問題になっています。政治は官僚が主導しますが、党派争いやスキャンダルが絶えません。幼い王太子は倫理的模範を志し、異世界に留学して多様な社会モデルを学んでいます。螺鈿細工や多彩な絵付けの陶磁器などの伝統工芸は後宮の庇護のもと発展。民間は明朗で色彩豊かで、王家以外では母系継承が一般的、働き者でおしゃれな女性たちが高く評価されています。夜市や水上マーケット、春分の「春色祭り」での色粉かけ合いなどが人々の融和を育んでいます。

## 気候
一年中温暖湿潤な熱帯または亜熱帯気候で、柑橘やハーブを多用した香り高くさっぱりした料理が好まれます。海に面し魚介類が豊富で、魚醤が調味料としてよく使われます。この気候は活発な屋外市場や夜市などのにぎやかな生活を支えています。

## 社会
政治は官僚主導で利害やスキャンダルにまみれがちで、報道は政治を消費的に扱いますが、民間は元気で柔軟な社会を築いています。宮廷は後宮発信のファッションや工芸で文化的影響力を持ち、民間は祭りや夜市、芸能を楽しみます。衣服や家具、陶磁器には鮮やかな色彩が好まれ、特に赤や緑が人気で、開放的で明るい社会気風を反映しています。
