
# Myusoasia Floating Continent Summary

## Culture
The Myusoasia Floating Continent is believed to be the body of the goddess Myusoasia, where sacred beasts (瑞獣) and humans coexist. Society relies on the spiritual power of the sacred beasts, who protect and manage nature. Seasons follow a harmonious cycle, and festivals mark solstices and equinoxes with spectacular atmospheric displays created by the beasts. Economy centers on gifting rather than trade, and artistic and social activities flourish. Priests act as mediators with the sacred beasts, caring for ...

## Climate
The floating continent enjoys regulated, harmonious natural cycles managed by the sacred beasts. All four seasons are present and coexist in balance across mountains, rivers, and forests. Unique flora and fauna thrive in a safe environment. On solstices or equinoxes, mystical weather phenomena appear, symbolizing divine blessing. The continent is isolated from other worlds by a spiritual immune-like barrier.

## Society
Humans live under the protection of sacred beasts and follow simple subsistence activities such as gathering, small-scale farming, and fishing. Gifting forms the basis of exchange, strengthening mutual gratitude between humans and beasts. Priests (巫覡) lead human communities by communicating with sacred beasts and educating others about them. The sacred beasts also act as the goddess’s emissaries, occasionally traveling to other worlds since humans cannot leave the floating continent on their own.

---

# ミュソーシア浮遊大陸 要約

## 文化
ミュソーシア浮遊大陸は女神ミュソーシアの身体とされ、瑞獣と人間が共存しています。社会は瑞獣の霊力に支えられ、彼らが自然を管理・保護しています。春夏秋冬が調和して巡り、冬至や春分などには瑞獣が生み出す美しい大気現象を楽しめます。経済は売買よりも贈与が中心で、芸術や社交が盛んです。巫覡が瑞獣との対話・ケアを担い、知識を広めています。自然の脅威はほとんどなく、多くの動植物は人間に優しい存在です。

## 気候
浮遊大陸は瑞獣によって調整された調和的な自然サイクルを持ちます。四季があり、山や川、森など多様な環境が共存しています。独自の動植物が安全な環境で生育し、冬至や春分などには神秘的な天候現象が現れます。大陸全体は、女神の免疫反応のような霊的防衛機能により他の世界から隔絶されています。

## 社会
人間は瑞獣の保護のもとで暮らし、採集や小規模な農業、漁業などのシンプルな生業を営んでいます。贈与が物々交換の中心で、瑞獣と人間の感謝と互助の関係を強化しています。巫覡が瑞獣との対話役として人間社会を導き、瑞獣に関する知識を広めます。また、瑞獣は女神の使者として他世界に赴くこともあり、人間たちは自力で浮遊大陸を離れる手段を持ちません。
